﻿namespace StockManage.DatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PRoduct : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Products", "Name", c => c.String(nullable: false, maxLength: 50));
            AlterColumn("dbo.Products", "Code", c => c.String(nullable: false, maxLength: 50));
            AlterColumn("dbo.Products", "Discription", c => c.String(nullable: false, maxLength: 50));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Products", "Discription", c => c.String());
            AlterColumn("dbo.Products", "Code", c => c.Int(nullable: false));
            AlterColumn("dbo.Products", "Name", c => c.String());
        }
    }
}
