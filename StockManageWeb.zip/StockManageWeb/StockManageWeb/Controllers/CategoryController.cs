﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StockManage.Models.Models;
using StockManage.BLL.BLL;

namespace StockManageWeb.Controllers
{
    public class CategoryController : Controller
    {
        StockManageManager _stockManageManger = new StockManageManager();
        Category _category = new Category();
        // GET: Category
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Add()
        {
            _category.categories = _stockManageManger.Show();

            return View(_category);
        }

        [HttpPost]
        public ActionResult Add(Category category)
        {
            if (ModelState.IsValid)

            {
                if (category.Name != null && category.Code != null)
                {
                    _stockManageManger.Add(category);
                    ViewBag.message = "Inserted";
                }
            }

            else
            {
                ViewBag.message = "Not Inserted";
            }

            _category.categories = _stockManageManger.Show();

            return View(_category);
        }

        [HttpPost]
        public ActionResult Show(Category category)
        {
            _category.categories = _stockManageManger.Show();
            if (category.Name != null)
            {
                _category.categories = _category.categories.Where(c => c.Name.ToLower().Contains(category.Name.ToLower())).ToList();
            }


            return View(_category);
        }

        public ActionResult Show()
        {

            _category.categories = _stockManageManger.Show();

            return View(_category);
        }

        public ActionResult Edit(int? id)
        {
            _category.ID = Convert.ToInt32(id);

            _category.categories = _stockManageManger.Show();
            var category = _stockManageManger.GetByID(_category);
            ViewBag.message = "Inserted";
            return View(category);
        }

        [HttpPost]
        public ActionResult Edit(Category category)
        {


            _category.Name = category.Name;
            _category.ID = category.ID;
            _category.Code = category.Code;
            _stockManageManger.Edit(_category);


            _category.categories = _stockManageManger.Show();

            return View(_category);
        }


        public ActionResult Delete(int? id)
        {
            _category.ID = Convert.ToInt32(id);
            if (id != null)
            {
                var category = _stockManageManger.GetByID(_category);
                _stockManageManger.Delete(category);
            }




            _category.categories = _stockManageManger.Show();
            return View(_category);

        }




    }
}